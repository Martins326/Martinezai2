import React, { useMemo, useState } from "react";

import {
  ArrowLeft,
  CheckCircle2,
  ExternalLink,
  Globe2,
  LoaderCircle,
  PlugZap,
  Search,
  Sparkles,
  TerminalSquare,
  WandSparkles,
  XCircle,
} from "lucide-react";

import {
  ASSISTANT_PLUGINS,
  type AssistantPlugin,
} from "../plugins/registry";

import {
  ApiService,
  type PluginRunResult,
} from "../services/api";

interface PluginsScreenProps {
  enabledPlugins: string[];

  isLight: boolean;

  onChange: (enabled: string[]) => void;

  onBack: () => void;

  onUseInChat: (message: string) => void;
}

const runtimeLabel: Record<
  AssistantPlugin["runtime"],
  string
> = {
  local: "Local tool",
  ai: "AI-powered",
  search: "AI + live search",
};

export const PluginsScreen: React.FC<
  PluginsScreenProps
> = ({
  enabledPlugins,
  isLight,
  onChange,
  onBack,
  onUseInChat,
}) => {
  const [selectedPluginId, setSelectedPluginId] =
    useState<string | null>(null);

  const [input, setInput] = useState("");

  const [running, setRunning] = useState(false);

  const [result, setResult] =
    useState<PluginRunResult | null>(null);

  const [error, setError] = useState("");

  const [searchTerm, setSearchTerm] = useState("");

  const panel = isLight
    ? "border-neutral-200 bg-white text-neutral-900"
    : "border-neutral-800 bg-neutral-900 text-neutral-100";

  const muted = isLight
    ? "text-neutral-500"
    : "text-neutral-400";

  const field = isLight
    ? "border-neutral-200 bg-neutral-50 text-neutral-900 placeholder:text-neutral-400"
    : "border-neutral-700 bg-neutral-950 text-neutral-100 placeholder:text-neutral-500";

  const selectedPlugin =
    ASSISTANT_PLUGINS.find(
      (plugin) => plugin.id === selectedPluginId
    ) || null;

  const filteredPlugins = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();

    if (!query) {
      return ASSISTANT_PLUGINS;
    }

    return ASSISTANT_PLUGINS.filter((plugin) =>
      [
        plugin.name,
        plugin.description,
        ...plugin.features,
      ]
        .join(" ")
        .toLowerCase()
        .includes(query)
    );
  }, [searchTerm]);

  const activeCount =
    ASSISTANT_PLUGINS.filter((plugin) =>
      enabledPlugins.includes(plugin.id)
    ).length;

  const searchCount =
    ASSISTANT_PLUGINS.filter(
      (plugin) =>
        enabledPlugins.includes(plugin.id) &&
        plugin.runtime === "search"
    ).length;

  const toggle = (id: string) => {
    onChange(
      enabledPlugins.includes(id)
        ? enabledPlugins.filter(
            (item) => item !== id
          )
        : [...enabledPlugins, id]
    );
  };

  const openPlayground = (
    plugin: AssistantPlugin
  ) => {
    setSelectedPluginId(plugin.id);

    setInput(plugin.sampleInput);

    setResult(null);

    setError("");
  };

  const runSelectedPlugin = async () => {
    if (
      !selectedPlugin ||
      !input.trim() ||
      running
    ) {
      return;
    }

    setRunning(true);

    setResult(null);

    setError("");

    try {
      const response =
        await ApiService.runPlugin({
          pluginId: selectedPlugin.id,
          input: input.trim(),
        });

      setResult(response);
    } catch (runError) {
      setError(
        runError instanceof Error
          ? runError.message
          : "The plugin could not run. Please try again."
      );
    } finally {
      setRunning(false);
    }
  };

  const continueInChat = () => {
    if (!selectedPlugin || !result) {
      return;
    }

    const sourceText = result.sources.length
      ? [
          "Sources returned by the plugin:",
          ...result.sources.map(
            (source) =>
              `- ${source.title}: ${source.uri}`
          ),
        ].join("\n")
      : "";

    const handoff = [
      `Continue from this ${selectedPlugin.name} result.`,

      `Original request/input:\n${input.trim()}`,

      `Plugin result (${result.provider}):\n${result.output}`,

      sourceText,

      "Use the result above as tool output. Do not claim that any additional checks or actions were performed.",
    ]
      .filter(Boolean)
      .join("\n\n");

    onUseInChat(handoff);
  };

  return (
    <div className="flex-1 min-h-0 overflow-y-auto">
      <div className="mx-auto w-full max-w-5xl space-y-6 px-4 py-6 sm:px-6 lg:px-8">

        {/* Header */}

        <header className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBack}
            className={`rounded-xl border p-2 transition hover:opacity-80 ${panel}`}
            aria-label="Back to chat"
          >
            <ArrowLeft size={18} />
          </button>

          <div className="min-w-0">
            <h1 className="text-2xl font-bold">
              Plugin Studio
            </h1>

            <p className={`mt-1 text-sm ${muted}`}>
              Enable tools for chat, then test them
              here before using them in a conversation.
            </p>
          </div>

          <PlugZap
            className="ml-auto shrink-0 text-indigo-400"
            size={27}
          />
        </header>

        {/* Plugin statistics */}

        <section
          className={`grid gap-3 rounded-2xl border p-4 sm:grid-cols-3 ${panel}`}
        >
          <div className="flex items-center gap-3">
            <span className="rounded-xl bg-indigo-500/10 p-2.5 text-indigo-400">
              <PlugZap size={20} />
            </span>

            <div>
              <p className="text-xl font-bold">
                {activeCount}/{ASSISTANT_PLUGINS.length}
              </p>

              <p className={`text-xs ${muted}`}>
                Enabled for chat
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="rounded-xl bg-emerald-500/10 p-2.5 text-emerald-500">
              <TerminalSquare size={20} />
            </span>

            <div>
              <p className="text-xl font-bold">
                1
              </p>

              <p className={`text-xs ${muted}`}>
                Deterministic local tool
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="rounded-xl bg-sky-500/10 p-2.5 text-sky-500">
              <Globe2 size={20} />
            </span>

            <div>
              <p className="text-xl font-bold">
                {searchCount}
              </p>

              <p className={`text-xs ${muted}`}>
                Search plugins enabled
              </p>
            </div>
          </div>

          <p
            className={`sm:col-span-3 border-t pt-3 text-xs leading-5 ${
              isLight
                ? "border-neutral-200"
                : "border-neutral-800"
            } ${muted}`}
          >
            The calculator runs locally on the
            server without an AI call. AI and search
            plugins use your configured Gemini server
            connection. These are built-in tools, not
            third-party OAuth integrations.
          </p>
        </section>

        {/* Plugin search */}

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative min-w-0 flex-1">
            <Search
              className={`pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 ${muted}`}
              size={17}
            />

            <input
              value={searchTerm}
              onChange={(event) =>
                setSearchTerm(event.target.value)
              }
              placeholder="Find a plugin or capability…"
              aria-label="Search plugins"
              className={`w-full rounded-xl border py-2.5 pl-9 pr-3 text-sm outline-none focus:border-indigo-500 ${field}`}
            />
          </div>

          <p className={`text-xs ${muted}`}>
            Enable it for chat or open the playground
            to run a test.
          </p>
        </div>

        {/* Plugin cards */}

        <div className="grid gap-3 md:grid-cols-2">
          {filteredPlugins.map((plugin) => {
            const enabled =
              enabledPlugins.includes(plugin.id);

            const selected =
              selectedPluginId === plugin.id;

            return (
              <article
                key={plugin.id}
                className={`rounded-2xl border p-4 transition ${panel} ${
                  selected
                    ? "ring-2 ring-indigo-500/60"
                    : ""
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="rounded-xl bg-indigo-500/10 p-3 text-indigo-400">
                    {plugin.icon}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="font-semibold">
                        {plugin.name}
                      </h2>

                      {enabled && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[11px] font-medium text-emerald-500">
                          <CheckCircle2 size={12} />
                          Enabled
                        </span>
                      )}
                    </div>

                    <p
                      className={`mt-1 text-sm leading-6 ${muted}`}
                    >
                      {plugin.description}
                    </p>

                    <p className="mt-2 text-xs font-medium text-indigo-400">
                      {runtimeLabel[plugin.runtime]}
                    </p>
                  </div>
                </div>

                <ul className="mt-4 flex flex-wrap gap-1.5">
                  {plugin.features.map((feature) => (
                    <li
                      key={feature}
                      className={`rounded-full border px-2 py-1 text-[11px] ${
                        isLight
                          ? "border-neutral-200 bg-neutral-50 text-neutral-600"
                          : "border-neutral-700 bg-neutral-950 text-neutral-300"
                      }`}
                    >
                      {feature}
                    </li>
                  ))}
                </ul>

                <div className="mt-4 grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    aria-pressed={enabled}
                    onClick={() => toggle(plugin.id)}
                    className={`rounded-xl px-3 py-2.5 text-sm font-semibold transition ${
                      enabled
                        ? "bg-indigo-600 text-white hover:bg-indigo-500"
                        : "border border-neutral-500/30 hover:bg-neutral-500/10"
                    }`}
                  >
                    {enabled
                      ? "Enabled · Turn off"
                      : "Enable for chat"}
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      selected
                        ? setSelectedPluginId(null)
                        : openPlayground(plugin)
                    }
                    className={`rounded-xl border px-3 py-2.5 text-sm font-semibold transition ${
                      isLight
                        ? "border-neutral-200 hover:bg-neutral-100"
                        : "border-neutral-700 hover:bg-neutral-800"
                    }`}
                  >
                    {selected
                      ? "Close playground"
                      : "Try plugin"}
                  </button>
                </div>
              </article>
            );
          })}
        </div>

        {/* Empty search state */}

        {filteredPlugins.length === 0 && (
          <div
            className={`rounded-2xl border p-8 text-center ${panel}`}
          >
            <Search
              size={24}
              className={`mx-auto ${muted}`}
            />

            <p className="mt-2 font-semibold">
              No matching plugins
            </p>

            <p className={`mt-1 text-sm ${muted}`}>
              Try a different name or capability.
            </p>
          </div>
        )}

        {/* Plugin playground */}

        {selectedPlugin && (
          <section
            className={`overflow-hidden rounded-2xl border ${panel}`}
          >
            <div
              className={`flex items-center gap-3 border-b p-4 ${
                isLight
                  ? "border-neutral-200 bg-neutral-50"
                  : "border-neutral-800 bg-neutral-950"
              }`}
            >
              <span className="rounded-xl bg-indigo-500/10 p-2.5 text-indigo-400">
                {selectedPlugin.icon}
              </span>

              <div className="min-w-0 flex-1">
                <h2 className="font-semibold">
                  {selectedPlugin.name} playground
                </h2>

                <p className={`text-xs ${muted}`}>
                  This runs the selected tool now. It
                  does not send a message to your chat
                  history.
                </p>
              </div>

              <button
                type="button"
                onClick={() =>
                  setSelectedPluginId(null)
                }
                className={`rounded-lg p-2 ${muted}`}
                aria-label="Close plugin playground"
              >
                <XCircle size={18} />
              </button>
            </div>

            <div className="space-y-3 p-4">
              <label
                className="block text-sm font-medium"
                htmlFor="plugin-playground-input"
              >
                Input
              </label>

              <textarea
                id="plugin-playground-input"
                value={input}
                onChange={(event) =>
                  setInput(event.target.value)
                }
                placeholder={selectedPlugin.placeholder}
                rows={
                  selectedPlugin.id === "calculator"
                    ? 2
                    : 6
                }
                maxLength={12000}
                className={`w-full resize-y rounded-xl border p-3 text-sm leading-6 outline-none focus:border-indigo-500 ${field}`}
              />

              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className={`text-xs ${muted}`}>
                  {input.length.toLocaleString()} / 12,000
                  {" "}characters
                </p>

                <button
                  type="button"
                  onClick={() =>
                    void runSelectedPlugin()
                  }
                  disabled={!input.trim() || running}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-500 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {running ? (
                    <>
                      <LoaderCircle
                        size={16}
                        className="animate-spin"
                      />
                      Running…
                    </>
                  ) : (
                    <>
                      <WandSparkles size={16} />
                      Run {selectedPlugin.name}
                    </>
                  )}
                </button>
              </div>

              {/* Execution error */}

              {error && (
                <div
                  role="alert"
                  className="rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-500"
                >
                  {error}
                </div>
              )}

              {/* Execution result */}

              {result && (
                <div
                  className={`space-y-3 rounded-xl border p-4 ${
                    isLight
                      ? "border-neutral-200 bg-neutral-50"
                      : "border-neutral-800 bg-neutral-950"
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2 font-semibold">
                      <CheckCircle2
                        size={17}
                        className="text-emerald-500"
                      />
                      Result
                    </div>

                    <span className={`text-xs ${muted}`}>
                      {result.provider === "local"
                        ? "Local execution"
                        : result.provider ===
                            "gemini-google-search"
                          ? "Gemini + Google Search"
                          : "Gemini AI"}
                    </span>
                  </div>

                  <pre className="whitespace-pre-wrap break-words font-sans text-sm leading-6">
                    {result.output}
                  </pre>

                  {/* Search sources */}

                  {result.sources.length > 0 && (
                    <div
                      className={`border-t pt-3 ${
                        isLight
                          ? "border-neutral-200"
                          : "border-neutral-800"
                      }`}
                    >
                      <p className="mb-2 text-xs font-semibold uppercase tracking-wide">
                        Sources returned by search
                      </p>

                      <ul className="space-y-2">
                        {result.sources.map((source) => (
                          <li key={source.uri}>
                            <a
                              href={source.uri}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-start gap-1.5 text-sm text-indigo-400 hover:underline"
                            >
                              <ExternalLink
                                size={14}
                                className="mt-1 shrink-0"
                              />

                              <span>
                                {source.title || source.uri}
                              </span>
                            </a>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Continue in chat */}

                  <div
                    className={`border-t pt-3 ${
                      isLight
                        ? "border-neutral-200"
                        : "border-neutral-800"
                    }`}
                  >
                    <button
                      type="button"
                      onClick={continueInChat}
                      className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-500"
                    >
                      <Sparkles size={16} />

                      Continue in chat with this result
                    </button>
                  </div>
                </div>
              )}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};